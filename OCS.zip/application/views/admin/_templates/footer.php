<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!-- blog promotion ends -->


<footer class="container text-center">
    
      
      <div class="copyrights" style="margin-top:25px;">
            <p>WebSSH &copy; 2018, All Rights Reserved
                <br>
                <span>Develop By: Adipati Arya</span></p>
            <p><a href="https://www.facebook.com/adipati.aarya" target="_blank">Facebook <i class="fa fa-facebook-square" aria-hidden="true"></i> </a></p>
        </div>
    
</footer>

</section>	
	
	
	<script src="<?php echo base_url('assets/panel/jquery/jquery.min.js') ?>" type="text/javascript"></script>
	
    <script src="<?php echo base_url('assets/panel/bootstrap/js/bootstrap.min.js') ?>"></script>
    
    <script src="<?php echo base_url('assets/panel/custom/js/custom.js') ?>"></script>
    	
     
</body>
</html>

